var typed= new Typed(".multiple-text", {
	strings: ["Frontend Developer", "YouTuber", "Graphics Designer"],
	typeSpeed: 100,
	backSpeed: 100,
	backDelay: 100,
	loop: true
})